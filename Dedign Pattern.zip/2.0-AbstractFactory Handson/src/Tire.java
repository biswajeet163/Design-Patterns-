
public abstract class Tire {

}
