
public class AudiTire extends Tire{

}
