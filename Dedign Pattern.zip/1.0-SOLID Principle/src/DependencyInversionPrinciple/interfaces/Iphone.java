package DependencyInversionPrinciple.interfaces;

public interface Iphone {
	String getPhonePart1();
	double getPart1Cost();
}
