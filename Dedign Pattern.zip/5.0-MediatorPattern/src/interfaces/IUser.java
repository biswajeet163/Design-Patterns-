package interfaces;

public interface IUser {
	void recieveMessage(String msgr);
	void sendMessage(String msgs);

}
